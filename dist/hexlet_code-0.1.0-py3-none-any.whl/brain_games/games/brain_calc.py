#!/usr/bin/env python3
from brain_games.scripts import engine
import random

def main():
    task_text = 'What is the result of the expression?'
    engine.welcome(task_text)
    name = engine.name
    number_question = 3
    count = 0
    while count < number_question:
        number_one = engine.randomaizer()
        number_two = engine.randomaizer()
        operator = engine.random_operators()
        task = str(number_one) + str(operator) + str(number_two)
        engine.question(task)
        if engine.answer == number_one + operator + number_two:
            print('Correct!')
            count += 1
        
    
    
if __name__ == '__main__':
    main()
