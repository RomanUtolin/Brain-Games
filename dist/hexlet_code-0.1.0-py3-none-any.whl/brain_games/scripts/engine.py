#!/usr/bin/env python3
import prompt
import random
import operator

def welcome(task_text):
    global name
    print('Welcome to the Brain Games!')
    name = prompt.string('May I have your name? ')
    greeting = 'Hello, ' + name + '!'
    print(greeting)
    print(task_text)
    return name

    
def question(task):
    global answer
    print('Question: ' + str(task))
    answer = prompt.string('You answer: ')
    return answer
    
def randomaizer():
    random_number = random.randrange(0, 101)
    return random_number
    
def random_operators():
    operator = [('+', operator.add), ('-', operator.sub), ('*', operator.mul)]
    random_operator = random.choice(operator)

    return random_operator
